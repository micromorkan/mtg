﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dados
{
    public class RankingView
    {
        public string Nome { get; set; }
        public int NumVitorias { get; set; }
        public int NumEmpates { get; set; }
        public int NumDerrotas { get; set; }
        public int Pontuacao { get; set; }
        public int NumJogos { get; set; }
        public string Deck { get; set; }
        public string Tribo { get; set; }
        public string Posicao { get; set; }
    }
}
