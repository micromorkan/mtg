﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dados
{
    public class JogosView
    {
        public string Data { get; set; }
        public string Placar { get; set; }
        public string Vencedor { get; set; }
        public string TriboOponente { get; set; }
        public string Oponente { get; set; }
        public string Resultado { get; set; }
        public string DeckOponente { get; set; }
        public string Status { get; set; }
    }
}
