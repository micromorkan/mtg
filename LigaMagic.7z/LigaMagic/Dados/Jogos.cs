﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dados
{
    public class Jogos
    {
        public string Id { get; set; }
        public string Id_Usuario_V { get; set; }
        public string Id_Usuario_P { get; set; }
        public string Placar_V { get; set; }
        public string Placar_P { get; set; }
        public string Id_Deck_V { get; set; }
        public string Id_Deck_P { get; set; }
        public string Empate { get; set; }
        public string Data { get; set; }
        public string Status{ get; set; }
        public string Id_Usuario_Cad { get; set; }
        public string Ponto_Reduzido { get; set; }
    }
}
