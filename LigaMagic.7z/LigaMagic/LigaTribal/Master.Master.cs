﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;

namespace LigaTribal
{
    public partial class Master : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["USER"] == null)
            {
                Response.Redirect("Index.aspx");
            }
            else
            {
                lblNome.Text = "Bem vindo, " + ((Usuario)Session["USER"]).Nome;
            }
        }    

        protected void btnSair_Onclick(object sender, EventArgs e)
        {
            Session["USER"] = null;
            Response.Redirect("Index.aspx");
        }
    }
}