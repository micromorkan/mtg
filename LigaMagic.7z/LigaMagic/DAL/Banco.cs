﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dados;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Data;

namespace DAL
{
    public class Banco
    {
        public void CadastrarUsuario(Usuario user)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = "INSERT INTO `liga`.`usuario` (`nome`,`email`,`senha`) VALUES (@nome, @email, @senha);";
                cmd.Parameters.AddWithValue("@nome", user.Nome);
                cmd.Parameters.AddWithValue("@email", user.Email);
                cmd.Parameters.AddWithValue("@senha", user.Senha);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public int VerificarUsuarioExistente(string email)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  COUNT(*)
                                    FROM `liga`.`usuario`
                                    WHERE `usuario`.`email` = @email;";

                cmd.Parameters.AddWithValue("@email", email);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);

                return Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ValidarUsuario(Usuario user)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `usuario`.`idusuario`,
                                            `usuario`.`nome`,
                                            `usuario`.`email`,
                                            `usuario`.`senha`
                                    FROM `liga`.`usuario`
                                    WHERE `usuario`.`email` = @email 
                                    AND `usuario`.`senha` = @senha;";

                cmd.Parameters.AddWithValue("@email", user.Email);
                cmd.Parameters.AddWithValue("@senha", user.Senha);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void CadastrarDeck(Deck deck)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"INSERT INTO `liga`.`deck`
                                        (`idusuario`,
                                        `tribo`,
                                        `qtdcards`,
                                        `listacards`,
                                        `dataatualizacao`,
                                        `status`,
                                        `cordeck`,
                                        `ativo`)
                                    VALUES
                                        (@idusuario,
                                        @tribo,
                                        @qtdcards,
                                        @listacards,
                                        NOW(),
                                        1,
                                        @cordeck,
                                        @ativo);";

                cmd.Parameters.AddWithValue("@idusuario", deck.Id_Usuario);
                cmd.Parameters.AddWithValue("@qtdcards", deck.Qtd_Cards);
                cmd.Parameters.AddWithValue("@tribo", deck.Tribo);
                cmd.Parameters.AddWithValue("@listacards", deck.Lista_Cards);
                cmd.Parameters.AddWithValue("@cordeck", deck.Cor_Deck);
                cmd.Parameters.AddWithValue("@ativo", deck.Ativo == "0" ? false : true);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterListaDecks(string idUsuario)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `deck`.`iddeck`,       
		                                    `deck`.`idusuario`,
		                                    `deck`.`tribo`,
		                                    `deck`.`qtdcards`,
		                                    `deck`.`listacards`,
		                                    `deck`.`dataatualizacao`,
		                                    `deck`.`status`,
		                                    `deck`.`cordeck`,
                                            `deck`.`ativo`
                                    FROM `liga`.`deck`
                                    WHERE `deck`.`idusuario` = @idusuario AND `deck`.`status` = 1;";

                cmd.Parameters.AddWithValue("@idusuario", idUsuario);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterDeckUsuario(Deck filtro)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `deck`.`iddeck`,       
		                                    `deck`.`idusuario`,
		                                    `deck`.`tribo`,
		                                    `deck`.`qtdcards`,
		                                    `deck`.`listacards`,
		                                    `deck`.`dataatualizacao`,
		                                    `deck`.`status`,
		                                    `deck`.`cordeck`,
                                            `deck`.`ativo`
                                    FROM `liga`.`deck`
                                    WHERE `deck`.`idusuario` = @idusuario AND `deck`.`iddeck` = @iddeck AND `deck`.`status` = 1;";

                cmd.Parameters.AddWithValue("@idusuario", filtro.Id_Usuario);
                cmd.Parameters.AddWithValue("@iddeck", filtro.Id);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void GerarHistoricoEAtualizarDeck(Deck deck)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"UPDATE `liga`.`deck`
                                    SET `status` = 0                                        
                                    WHERE `deck`.`idusuario` = @idusuario AND `deck`.`iddeck` = @iddeck AND `deck`.`status` = 1;

                                    INSERT INTO `liga`.`deck`
                                        (`idusuario`,
                                        `tribo`,
                                        `qtdcards`,
                                        `listacards`,
                                        `dataatualizacao`,
                                        `status`,
                                        `cordeck`,
                                        `ativo`)
                                    VALUES
                                        (@idusuario,
                                        @tribo,
                                        @qtdcards,
                                        @listacards,
                                        NOW(),
                                        1,
                                        @cordeck,
                                        @ativo);";

                cmd.Parameters.AddWithValue("@iddeck", deck.Id);
                cmd.Parameters.AddWithValue("@idusuario", deck.Id_Usuario);
                cmd.Parameters.AddWithValue("@qtdcards", deck.Qtd_Cards);
                cmd.Parameters.AddWithValue("@tribo", deck.Tribo);
                cmd.Parameters.AddWithValue("@listacards", deck.Lista_Cards);
                cmd.Parameters.AddWithValue("@cordeck", deck.Cor_Deck);
                cmd.Parameters.AddWithValue("@ativo", deck.Ativo == "0" ? false : true);
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void DeletarDeck(Deck deck)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"UPDATE `liga`.`deck`
                                    SET `status` = 0                                        
                                    WHERE `deck`.`idusuario` = @idusuario AND `deck`.`iddeck` = @iddeck AND `deck`.`status` = 1;";


                cmd.Parameters.AddWithValue("@iddeck", deck.Id);
                cmd.Parameters.AddWithValue("@idusuario", deck.Id_Usuario);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterListaJogos(string idUsuario, string mesReferencia, string anoReferencia)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT 	`jogos`.`idjogos`,
                                            `jogos`.`idusuariocad`,
                                            `jogos`.`data`,
		                                    `jogos`.`placarv`,
                                            `jogos`.`placarp`,
                                            `jogos`.`empate`,			                                    
		                                    `jogos`.`idusuariov` AS 'vencedor',
                                            `deck`.`tribo` AS 'tribo_oponente',
                                            (CASE WHEN `jogos`.`idusuariov` = `usuario`.`idusuario` 
                                                                       THEN `jogos`.`idusuariop`
                                                                       ELSE `jogos`.`idusuariov`
                                                                   END) AS 'oponente',
	                                        `deck`.`listacards` AS 'deck_oponente',
                                            `jogos`.`status`
                                    FROM `liga`.`jogos`
                                    INNER JOIN `usuario`
                                    ON `usuario`.`idusuario`= (CASE WHEN `jogos`.`idusuariov` = @idusuario
                                                                       THEN `jogos`.`idusuariov`
                                                                       ELSE `jogos`.`idusuariop`
                                                                   END)
                                    INNER JOIN `deck`
                                    ON `deck`.`iddeck` = (CASE WHEN `jogos`.`idusuariov` != @idusuario 
                                                                       THEN `jogos`.`iddeckv`
                                                                       ELSE `jogos`.`iddeckp`
                                                                   END)
                                    WHERE (`jogos`.`idusuariov` = @idusuario OR `jogos`.`idusuariop` = @idusuario) AND MONTH(`jogos`.`data`) = @mesreferencia AND YEAR(`jogos`.`data`) = @anoreferencia;";

                cmd.Parameters.AddWithValue("@idusuario", idUsuario);
                cmd.Parameters.AddWithValue("@mesreferencia", mesReferencia);
                cmd.Parameters.AddWithValue("@anoreferencia", anoReferencia);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void DesativarTodosDecks(Deck deck)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"UPDATE `liga`.`deck`
                                    SET `ativo` = 0                                        
                                    WHERE `deck`.`idusuario` = @idusuario;";

                cmd.Parameters.AddWithValue("@idusuario", deck.Id_Usuario);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterJogadoresAtivos()
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `rankingmensal`.`idusuario`,
                                            `usuario`.`nome`,
                                            `deck`.`tribo`,
                                            `deck`.`iddeck`
                                    FROM `liga`.`rankingmensal`
                                    INNER JOIN `usuario`
                                    ON `usuario`.`idusuario`= `rankingmensal`.`idusuario`
                                    INNER JOIN `deck`
                                    ON `deck`.`iddeck`= `rankingmensal`.`iddeck`
                                    WHERE `rankingmensal`.`mesreferencia` = MONTH(CURDATE()) AND `rankingmensal`.`anoreferencia` = YEAR(CURDATE());";

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterJogosMensais(string idUsuario, string mesReferencia, string anoReferencia, bool somenteAtivos = false)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();

                if (somenteAtivos)
                {
                    cmd.CommandText = @"SELECT `jogos`.`idjogos`,
                                        `jogos`.`idusuariov`,
                                        `jogos`.`idusuariop`,
                                        `jogos`.`placarv`,
                                        `jogos`.`placarp`,
                                        `jogos`.`iddeckv`,
                                        `jogos`.`iddeckp`,
                                        `jogos`.`empate`,
                                        `jogos`.`data`,
                                        `jogos`.`status`,
                                        `jogos`.`idusuariocad`,
                                        `jogos`.`pontoreduzido`
                                    FROM `liga`.`jogos`
                                    WHERE (`jogos`.`idusuariov` = @idusuario OR `jogos`.`idusuariop` = @idusuario) AND MONTH(`jogos`.`data`) = @mes AND YEAR(`jogos`.`data`) = @ano AND `jogos`.`status` = 1;";
                }
                else
                {
                    cmd.CommandText = @"SELECT `jogos`.`idjogos`,
                                        `jogos`.`idusuariov`,
                                        `jogos`.`idusuariop`,
                                        `jogos`.`placarv`,
                                        `jogos`.`placarp`,
                                        `jogos`.`iddeckv`,
                                        `jogos`.`iddeckp`,
                                        `jogos`.`empate`,
                                        `jogos`.`data`,
                                        `jogos`.`status`,
                                        `jogos`.`idusuariocad`,
                                        `jogos`.`pontoreduzido`
                                    FROM `liga`.`jogos`
                                    WHERE (`jogos`.`idusuariov` = @idusuario OR `jogos`.`idusuariop` = @idusuario) AND MONTH(`jogos`.`data`) = @mes AND YEAR(`jogos`.`data`) = @ano;";
                }

                cmd.Parameters.AddWithValue("@idusuario", idUsuario);
                cmd.Parameters.AddWithValue("@mes", mesReferencia);
                cmd.Parameters.AddWithValue("@ano", anoReferencia);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void IncluirJogo(Jogos jogo)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"INSERT INTO `liga`.`jogos`
                                        (`idusuariov`,
                                        `idusuariop`,
                                        `placarv`,
                                        `placarp`,
                                        `iddeckv`,
                                        `iddeckp`,
                                        `empate`,
                                        `data`,
                                        `status`,
                                        `idusuariocad`,
                                        `pontoreduzido`)
                                    VALUES
                                        (@idusuariov,
                                         @idusuariop,
                                         @placarv,
                                         @placarp,
                                         @iddeckv,
                                         @iddeckp,
                                         @empate,
                                         STR_TO_DATE(@data, '%Y-%m-%d'), 
                                         0,
                                         @idusuariocad,
                                         @pontoreduzido);";

                cmd.Parameters.AddWithValue("@idusuariov", jogo.Id_Usuario_V);
                cmd.Parameters.AddWithValue("@idusuariop", jogo.Id_Usuario_P);
                cmd.Parameters.AddWithValue("@placarv", jogo.Placar_V);
                cmd.Parameters.AddWithValue("@placarp", jogo.Placar_P);
                cmd.Parameters.AddWithValue("@iddeckv", jogo.Id_Deck_V);
                cmd.Parameters.AddWithValue("@iddeckp", jogo.Id_Deck_P);
                cmd.Parameters.AddWithValue("@empate", jogo.Empate == "0" ? false : true);
                cmd.Parameters.AddWithValue("@data", jogo.Data);
                cmd.Parameters.AddWithValue("@idusuariocad", jogo.Id_Usuario_Cad);
                cmd.Parameters.AddWithValue("@pontoreduzido", jogo.Ponto_Reduzido == "0" ? false : true);
            
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public string PesquisarNomeUsuario(string idUsuario)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `usuario`.`nome`
                                    FROM `liga`.`usuario`
                                    WHERE `usuario`.`idusuario` = @idusuario;";

                cmd.Parameters.AddWithValue("@idusuario", idUsuario);
                
                return cmd.ExecuteScalar().ToString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void ConfirmarJogo(string idJogo)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"UPDATE `liga`.`jogos`
                                    SET `status` = 1                                        
                                    WHERE `jogos`.`idjogos` = @idjogo;";

                cmd.Parameters.AddWithValue("@idjogo", idJogo);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public void CancelarJogo(string idJogo)
        {
            MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"DELETE FROM `liga`.`jogos`
                                    WHERE `jogos`.`idjogos` = @idjogo;";

                cmd.Parameters.AddWithValue("@idjogo", idJogo);

                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }

        public DataTable ObterListaParticipantes(string numMes, string numAno)
        {
             MySqlConnection connection = new MySqlConnection(ConfigurationManager.ConnectionStrings["BANCO"].ConnectionString);
            MySqlCommand cmd;

            connection.Open();

            try
            {
                cmd = connection.CreateCommand();
                cmd.CommandText = @"SELECT  `usuario`.`nome`,
		                                    `rankingmensal`.`idusuario`,
		                                    `rankingmensal`.`iddeck`,
                                            `deck`.`tribo`,
                                            `deck`.`listacards`
                                    FROM `liga`.`rankingmensal`
                                    INNER JOIN `liga`.`usuario` 
                                    ON `usuario`.`idusuario` = `rankingmensal`.`idusuario`
                                    INNER JOIN `liga`.`deck` 
                                    ON `deck`.`iddeck` = `rankingmensal`.`iddeck`
                                    WHERE `rankingmensal`.`mesreferencia` = @mes AND `rankingmensal`.`anoreferencia` = @ano;";

                cmd.Parameters.AddWithValue("@mes", numMes);
                cmd.Parameters.AddWithValue("@ano", numAno);

                MySqlDataAdapter adap = new MySqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                adap.Fill(dt);

                return dt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }
            }
        }
    }
}
