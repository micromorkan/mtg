﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;

namespace LigaTribal
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CarregarGridRanking(DateTime.Now.Month.ToString(), DateTime.Now.Date.Year.ToString());
            }
        }

        protected void btnCadastrar_Onclick(object sender, EventArgs e)
        {
            Response.Redirect("Cadastro.aspx");
        }

        protected void btnLogar_Onclick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtlogin.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorNome", "<script> sweetAlert('Aviso!', 'Campo Email não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtPassword.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorNome", "<script> sweetAlert('Aviso!', 'Campo Senha não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (!txtlogin.Text.Contains('@') || !txtlogin.Text.Contains('.'))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorNome", "<script> sweetAlert('Aviso!', 'Campo Email está incorreto.', 'warning'); </script> ", false);
            }
            else
            {
                Usuario user = new Usuario();

                user.Email = txtlogin.Text;
                user.Senha = txtPassword.Text;

                try
                {
                    user = new Negocio().ValidarUsuario(user);

                    Session["USER"] = user;
                    Session["NOMEUSUARIO"] = user.Nome;

                    Response.Redirect("Ranking.aspx");
                }
                catch (LigaException lex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Aviso!', '" + lex.Texto + "', '" + lex.TipoErro.ToDescriptionString() + "'); </script> ", false);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Erro!', '" + ex.Message + "', 'error'); </script> ", false);
                }
            }
        }

        private void CarregarGridRanking(string numMes, string numAno)
        {
            lbltitulo.Text = ObterNomeMes(Convert.ToInt32(numMes)) + " - " + numAno;

            grvRanking.DataSource = new Negocio().ObterRankingMensal(numMes, numAno);
            grvRanking.DataBind();

            if (grvRanking.Rows.Count > 0)
            {
                grvRanking.HeaderRow.TableSection = TableRowSection.TableHeader;
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "GRIDRANKING", "<script>$('#grvRanking').DataTable({ responsive: true, paging: false, \"language\": { \"sEmptyTable\": \"Nenhum registro encontrado\", \"sInfo\": \"Mostrando de _START_ até _END_ de _TOTAL_ registros\", \"sInfoEmpty\": \"Mostrando 0 até 0 de 0 registros\", \"sInfoFiltered\": \"(Filtrados de _MAX_ registros)\", \"sInfoPostFix\": \"\", \"sInfoThousands\": \".\", \"sLengthMenu\": \"_MENU_ resultados por página\", \"sLoadingRecords\": \"Carregando...\", \"sProcessing\": \"Processando...\", \"sZeroRecords\": \"Nenhum registro encontrado\", \"sSearch\": \"Pesquisar\", \"oPaginate\": { \"sNext\": \"Próximo\", \"sPrevious\": \"Anterior\", \"sFirst\": \"Primeiro\", \"sLast\": \"Último\" }, \"oAria\": { \"sSortAscending\": \": Ordenar colunas de forma ascendente\", \"sSortDescending\": \": Ordenar colunas de forma descendente\" } } }); </script>", false);
        }

        private string ObterNomeMes(int mes)
        {
            string nomeMes = string.Empty;

            switch (mes)
            {
                case 1:
                    nomeMes = "Janeiro";
                    break;
                case 2:
                    nomeMes = "Fevereiro";
                    break;
                case 3:
                    nomeMes = "Março";
                    break;
                case 4:
                    nomeMes = "Abril";
                    break;
                case 5:
                    nomeMes = "Maio";
                    break;
                case 6:
                    nomeMes = "Junho";
                    break;
                case 7:
                    nomeMes = "Julho";
                    break;
                case 8:
                    nomeMes = "Agosto";
                    break;
                case 9:
                    nomeMes = "Setembro";
                    break;
                case 10:
                    nomeMes = "Outrubo";
                    break;
                case 11:
                    nomeMes = "Novembro";
                    break;
                case 12:
                    nomeMes = "Dezembro";
                    break;
            }

            return nomeMes;
        }
    }
}