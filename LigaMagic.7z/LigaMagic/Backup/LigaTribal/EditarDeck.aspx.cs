﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;

namespace LigaTribal
{
    public partial class EditarDeck : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["USER"] == null)
                {
                    Response.Redirect("Index.aspx");
                }
                else if (Session["IDDECK"] == null)
                {
                    Response.Redirect("Decks.aspx");
                }
                else
                {
                    hdfIdUsuario.Value = ((Usuario)Session["USER"]).Id;
                    hdfIdDeck.Value = Session["IDDECK"].ToString();
                    CarregarDadosDeck(hdfIdDeck.Value, hdfIdUsuario.Value);
                }
            }
        }

        private void CarregarDadosDeck(string idDeck, string idUsuario)
        {
            Deck deck = new Negocio().ObterDeckUsuario(new Deck { Id = idDeck, Id_Usuario = idUsuario });

            txtQtdCartas.Text = deck.Qtd_Cards;
            ddlTribo.SelectedIndex = ddlTribo.Items.IndexOf(ddlTribo.Items.FindByText(deck.Tribo));
            txtCartas.Text = deck.Lista_Cards;
            rdlPrincipal.SelectedIndex = rdlPrincipal.Items.IndexOf(rdlPrincipal.Items.FindByValue(deck.Ativo));

            for (int i = 0; i < deck.Cor_Deck.Length; i++)
            {
                foreach (ListItem item in cklCor.Items)
                {
                    if (item.Value == deck.Cor_Deck.Substring(i, 1))
                    {
                        item.Selected = true;
                    }
                }
            }
        }

        protected void btnVoltar_OnClick(object sender, EventArgs e)
        {
            this.Response.Redirect("Decks.aspx");
        }

        protected void btnSalvar_OnClick(object sender, EventArgs e)
        {
            int numCartas = 0;

            if (ddlTribo.SelectedItem.Value == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorTribo", "<script> sweetAlert('Aviso!', 'Escolha uma tribo.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtQtdCartas.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtd", "<script> sweetAlert('Aviso!', 'Campo Qtd Cartas não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (cklCor.SelectedItem == null || string.IsNullOrEmpty(cklCor.SelectedItem.Value))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorCor", "<script> sweetAlert('Aviso!', 'Selecione pelo menos uma cor do seu deck.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtCartas.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorCartas", "<script> sweetAlert('Aviso!', 'Preencha sua lista de cartas.', 'warning'); </script> ", false);
            }
            else if (!Int32.TryParse(txtQtdCartas.Text, out numCartas))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtdValor", "<script> sweetAlert('Aviso!', 'Campo Qtd Cartas deve ser numérico.', 'warning'); </script> ", false);
            }
            else if (numCartas < 60)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtdMin", "<script> sweetAlert('Aviso!', 'O número de cartas não pode ser inferior a 60.', 'warning'); </script> ", false);
            }
            else
            {
                Deck deck = new Deck();

                deck.Id = hdfIdDeck.Value;
                deck.Id_Usuario = hdfIdUsuario.Value;
                deck.Qtd_Cards = numCartas.ToString();
                deck.Tribo = ddlTribo.SelectedItem.Value;
                deck.Lista_Cards = txtCartas.Text;
                deck.Ativo = rdlPrincipal.SelectedItem.Value;

                foreach (ListItem item in cklCor.Items)
                {
                    if (item.Selected)
                    {
                        deck.Cor_Deck = deck.Cor_Deck + item.Value;
                    }
                }

                try
                {
                    if (deck.Ativo == "1")
                    {
                        new Negocio().DeckPrincipal(deck);
                    }

                    new Negocio().AtualizarDeck(deck);

                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SucessoAtualizarDeck", "<script> swal({ title: 'Sucesso!', text: 'Deck atualizado.', type: 'success' }, function(){ window.location.href = 'Decks.aspx'; }); </script> ", false);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Erro!', '" + ex.Message + "', 'error'); </script> ", false);
                }
            }
        }
    }
}