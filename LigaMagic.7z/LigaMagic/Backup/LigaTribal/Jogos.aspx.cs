﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;
using System.Configuration;
using System.Web.Services;

namespace LigaTribal
{
    public partial class Jogos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["USER"] == null)
                {
                    Response.Redirect("Index.aspx");
                }
                else
                {
                    hdfIdUsuario.Value = ((Usuario)Session["USER"]).Id;
                    CarregarGridJogos(((Usuario)Session["USER"]).Id, DateTime.Now.Month.ToString(), DateTime.Now.Date.Year.ToString());
                }
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "MENU", "<script>$('li').removeClass('active'); $('ul li:nth-child(2)').addClass('active') </script>", false);
        }

        private void CarregarGridJogos(string idUsuario, string mesReferencia, string anoReferencia)
        {
            ddlMesReferencia.SelectedIndex = ddlMesReferencia.Items.IndexOf(ddlMesReferencia.Items.FindByValue(mesReferencia + "&" + anoReferencia));

            List<JogosView> lista = new Negocio().ObterListaJogos(idUsuario, mesReferencia, anoReferencia);

            grvJogos.DataSource = lista;
            grvJogos.DataBind();

            if (grvJogos.Rows.Count > 0)
            {
                grvJogos.HeaderRow.TableSection = TableRowSection.TableHeader;
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "GRIDJOGOS", "<script>$('#ContentPlaceHolder1_grvJogos').DataTable({ responsive: true, paging: false, \"language\": { \"sEmptyTable\": \"Nenhum registro encontrado\", \"sInfo\": \"Mostrando de _START_ até _END_ de _TOTAL_ registros\", \"sInfoEmpty\": \"Mostrando 0 até 0 de 0 registros\", \"sInfoFiltered\": \"(Filtrados de _MAX_ registros)\", \"sInfoPostFix\": \"\", \"sInfoThousands\": \".\", \"sLengthMenu\": \"_MENU_ resultados por página\", \"sLoadingRecords\": \"Carregando...\", \"sProcessing\": \"Processando...\", \"sZeroRecords\": \"Nenhum registro encontrado\", \"sSearch\": \"Pesquisar\", \"oPaginate\": { \"sNext\": \"Próximo\", \"sPrevious\": \"Anterior\", \"sFirst\": \"Primeiro\", \"sLast\": \"Último\" }, \"oAria\": { \"sSortAscending\": \": Ordenar colunas de forma ascendente\", \"sSortDescending\": \": Ordenar colunas de forma descendente\" } } }); </script>", false);
        }

        [WebMethod]
        public static string ConfirmarJogo(string idJogo)
        {
            string mensagem = string.Empty;

            try
            {
                new Negocio().ConfirmarJogo(idJogo);
                mensagem = "Jogo Confirmado.";
            }
            catch (Exception ex)
            {
                mensagem = "Não foi concluir sua solicitação. " + ex.Message;
            }

            return mensagem;
        }

        [WebMethod]
        public static string CancelarJogo(string idJogo)
        {
            string mensagem = string.Empty;

            try
            {
                new Negocio().CancelarJogo(idJogo);
                mensagem = "Jogo Cancelado.";
            }
            catch (Exception ex)
            {
                mensagem = "Não foi concluir sua solicitação. " + ex.Message;
            }

            return mensagem;
        }

        protected void grvJogos_OnDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string icon = ((JogosView)e.Row.DataItem).Resultado;
                string listaCartas = ((JogosView)e.Row.DataItem).DeckOponente;
                string tribo = ((JogosView)e.Row.DataItem).TriboOponente;
                string status = ((JogosView)e.Row.DataItem).Status;

                ((Literal)e.Row.Cells[4].FindControl("litResultado")).Text = icon;

                string buttons = "<button type='button' class='btn btn-warning btn-xs' onclick=\"" +
               "$('#ContentPlaceHolder1_txtCartas').val('" + listaCartas + "');" +
               "$('#deck').modal('show');" +
               "\">" + tribo + "</button>";

                ((Literal)e.Row.Cells[3].FindControl("litDeck")).Text = buttons;

                ((Literal)e.Row.Cells[5].FindControl("litStatus")).Text = status;
            }
        }

        protected void btnCadastrarJogo_OnClick(object sender, EventArgs e)
        {
            this.Response.Redirect("NovoJogo.aspx");
        }

        protected void ddlMesReferencia_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            CarregarGridJogos(hdfIdUsuario.Value, ((DropDownList)sender).SelectedItem.Value.Split('&')[0], ((DropDownList)sender).SelectedItem.Value.Split('&')[1]);
        }
    }
}