﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;
using System.Globalization;

namespace LigaTribal
{
    public partial class NovoJogo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["USER"] == null)
                {
                    Response.Redirect("Index.aspx");
                }
                else
                {
                    hdfIdUsuario.Value = ((Usuario)Session["USER"]).Id;
                    CarregarDados();
                }
            }           

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "MENU", "<script>$('li').removeClass('active'); $('ul li:nth-child(2)').addClass('active'); </script>", false);
        }

        private void CarregarDados()
        {
            txtDataJogo.Text = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString().PadLeft(2, '0') + "-" + DateTime.Now.Day.ToString().PadLeft(2, '0');

            List<Usuario> lista = new Negocio().ObterJogadoresAtivos();

            ddlJogadorP.Items.Clear();
            ddlJogadorV.Items.Clear();

            ddlJogadorP.Items.Add(new ListItem { Text = "-- Selecione --", Value = "0", Selected = true });
            ddlJogadorV.Items.Add(new ListItem { Text = "-- Selecione --", Value = "0", Selected = true });

            foreach (Usuario item in lista)
            {
                ddlJogadorP.Items.Add(new ListItem { Text = item.Nome, Value = item.Id });
                ddlJogadorV.Items.Add(new ListItem { Text = item.Nome, Value = item.Id });
            }
        }

        protected void btnVoltar_OnClick(object sender, EventArgs e)
        {
            this.Response.Redirect("Jogos.aspx");
        }

        protected void rdlEmpate_OnSelectedIndexChanged(object sender, EventArgs e)
        {
            if (((RadioButtonList)sender).SelectedItem.Value == "0")
            {
                txtJogosP.Enabled = true;
                txtJogosV.Enabled = true;
                txtJogosP.Text = string.Empty;
                txtJogosV.Text = string.Empty;
            }
            else
            {
                txtJogosP.Enabled = false;
                txtJogosV.Enabled = false;
                txtJogosP.Text = "1";
                txtJogosV.Text = "1";
            }
        }

        protected void btnSalvar_OnClick(object sender, EventArgs e)
        {
            int numJogosP = 0;
            int numJogosV = 0;
            DateTime data;

            if (string.IsNullOrEmpty(txtDataJogo.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorData", "<script> sweetAlert('Aviso!', 'Selecione uma data.', 'warning'); </script> ", false);
            }
            else if (!DateTime.TryParse(txtDataJogo.Text, out data))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorDataInvalida", "<script> sweetAlert('Aviso!', 'Campo de data está em um formato inválido.', 'warning'); </script> ", false);
            }
            else if (data.Date > DateTime.Now.Date)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorCor", "<script> sweetAlert('Aviso!', 'A data selecionada está acima da data atual.', 'warning'); </script> ", false);
            }
            else if (ddlJogadorP.SelectedItem.Value == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorJogadorPNS", "<script> sweetAlert('Aviso!', 'Escolha um jogador perdedor.', 'warning'); </script> ", false);
            }
            else if (ddlJogadorV.SelectedItem.Value == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorJogadorVNS", "<script> sweetAlert('Aviso!', 'Escolha um jogador vencedor.', 'warning'); </script> ", false);
            }
            else if (ddlJogadorP.SelectedItem.Value == ddlJogadorV.SelectedItem.Value)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorJogadorIgual", "<script> sweetAlert('Aviso!', 'Os jogadores não podem ser iguais.', 'warning'); </script> ", false);
            }
            else if (rdlEmpate.SelectedItem.Value == "0" && !Int32.TryParse(txtJogosP.Text, out numJogosP))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorJogosPInvalido", "<script> sweetAlert('Aviso!', 'Campo Qtd Jogos Ganhos (Perdedor) está invalido.', 'warning'); </script> ", false);
            }
            else if (rdlEmpate.SelectedItem.Value == "0" && !Int32.TryParse(txtJogosV.Text, out numJogosV))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorJogosVinvalido", "<script> sweetAlert('Aviso!', 'Campo Qtd Jogos Ganhos (Vencedor) está invalido.', 'warning'); </script> ", false);
            }
            else if(rdlEmpate.SelectedItem.Value == "0" && numJogosP + numJogosV != 2 && numJogosP + numJogosV != 3)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtdJogosInvalido", "<script> sweetAlert('Aviso!', 'Quantidade de Jogos entre os jogadores está incorreto.', 'warning'); </script> ", false);
            }
            else if (rdlEmpate.SelectedItem.Value == "0" && numJogosP == 1 && numJogosV == 1)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmpateFake", "<script> sweetAlert('Aviso!', 'Se o jogo terminou 1x1, marque a opção EMPATE acima.', 'warning'); </script> ", false);
            }
            else
            {
                Dados.Jogos jogo = new Dados.Jogos();

                jogo.Data = data.ToShortDateString();
                jogo.Empate = rdlEmpate.SelectedItem.Value;
                jogo.Id_Usuario_Cad = hdfIdUsuario.Value;
                jogo.Placar_P = txtJogosP.Text;
                jogo.Placar_V = txtJogosV.Text;
                jogo.Id_Deck_P = ddlJogadorP.SelectedItem.Value.Split('&')[1];
                jogo.Id_Deck_V = ddlJogadorV.SelectedItem.Value.Split('&')[1];
                jogo.Id_Usuario_P = ddlJogadorP.SelectedItem.Value.Split('&')[0];
                jogo.Id_Usuario_V = ddlJogadorV.SelectedItem.Value.Split('&')[0];

                try
                {
                    new Negocio().IncluirJogo(jogo);

                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SucessoIncluirJogo", "<script> swal({ title: 'Sucesso!', text: 'Duelo cadastrado. Aguardando confirmação do seu oponente.', type: 'success' }, function(){ window.location.href = 'Jogos.aspx'; }); </script> ", false);
                }
                catch (LigaException lex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Aviso!', '" + lex.Texto + "', '" + lex.TipoErro.ToDescriptionString() + "'); </script> ", false);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Erro!', '" + ex.Message + "', 'error'); </script> ", false);
                }
            }
        }
    }
}