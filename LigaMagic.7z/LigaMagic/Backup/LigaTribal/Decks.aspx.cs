﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;
using System.Data;
using System.Configuration;
using System.Web.Services;
using System.Text;

namespace LigaTribal
{
    public partial class Decks : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["USER"] == null)
                {
                    Response.Redirect("Index.aspx");
                }
                else
                {
                    hdfIdUsuario.Value = ((Usuario)Session["USER"]).Id;
                }
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "MENU", "<script>$('li').removeClass('active'); $('ul li:nth-child(3)').addClass('active'); </script>", false);

            CarregarGridDecks(hdfIdUsuario.Value);
        }

        private void CarregarGridDecks(string idUsuario)
        {
            List<Deck> lista = new Negocio().ObterListaDecks(idUsuario);

            grvDecks.DataSource = lista;
            grvDecks.DataBind();

            if (grvDecks.Rows.Count > 0)
            {
                grvDecks.HeaderRow.TableSection = TableRowSection.TableHeader;
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "GRIDDECK", "<script>$('#ContentPlaceHolder1_grvDecks').DataTable({ responsive: true, paging: false, \"language\": { \"sEmptyTable\": \"Nenhum registro encontrado\", \"sInfo\": \"Mostrando de _START_ até _END_ de _TOTAL_ registros\", \"sInfoEmpty\": \"Mostrando 0 até 0 de 0 registros\", \"sInfoFiltered\": \"(Filtrados de _MAX_ registros)\", \"sInfoPostFix\": \"\", \"sInfoThousands\": \".\", \"sLengthMenu\": \"_MENU_ resultados por página\", \"sLoadingRecords\": \"Carregando...\", \"sProcessing\": \"Processando...\", \"sZeroRecords\": \"Nenhum registro encontrado\", \"sSearch\": \"Pesquisar\", \"oPaginate\": { \"sNext\": \"Próximo\", \"sPrevious\": \"Anterior\", \"sFirst\": \"Primeiro\", \"sLast\": \"Último\" }, \"oAria\": { \"sSortAscending\": \": Ordenar colunas de forma ascendente\", \"sSortDescending\": \": Ordenar colunas de forma descendente\" } } }); </script>", false);
        }

        protected void grvDecks_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("Editar"))
            {
                string idDeck = e.CommandArgument.ToString();

                if (!String.IsNullOrEmpty(idDeck))
                {
                    Session["IDDECK"] = idDeck;
                    Response.Redirect("EditarDeck.aspx");
                }
            }
            else if (e.CommandName.Equals("Excluir"))
            {
                string idDeck = e.CommandArgument.ToString();

                if (!String.IsNullOrEmpty(idDeck))
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "DELETARDECK", "<script> swal({ title: 'Você tem certeza?', text: 'Após a exclusão não será mais possível recuperar o deck!', type: 'warning', showCancelButton: true, confirmButtonColor: '#DD6B55', confirmButtonText: 'Sim, Deletar!', closeOnConfirm: false }, function(){ $.ajax({type: \"POST\",url: \"Decks.aspx/ExcluirDeck\",data: '{\"idDeckUsuario\": \"" + idDeck + "&" + hdfIdUsuario.Value + "\"}',contentType: \"application/json; charset=utf-8\",dataType: \"json\",success: function(response) { swal({ title: 'Sucesso!', text: response.d, type: 'success' }, function(){ window.location.href = 'Decks.aspx'; }); },error: function(response) { swal('Error!', response.d, 'error');}});});  </script>", false);
                }
            }
        }

        [WebMethod]
        public static string ExcluirDeck(string idDeckUsuario)
        {
            string mensagem = string.Empty;

            try
            {
                new Negocio().DeletarDeck(new Deck { Id = idDeckUsuario.Split('&')[0], Id_Usuario = idDeckUsuario.Split('&')[1] });
                mensagem = "Deck Apagado.";
            }
            catch (Exception ex)
            {
                mensagem = "Não foi possível deletar. " + ex.Message;
            }

            return mensagem;
        }

        protected void grvDecks_OnDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                string cor = ((Deck)e.Row.DataItem).Cor_Deck;
                string listaCartas = ((Deck)e.Row.DataItem).Lista_Cards;
                string imagens = string.Empty;

                for (int i = 0; i < cor.Length; i++)
                {
                    imagens = imagens + "<img src='images/" + cor.Substring(i, 1) + ".png' class='img-responsive pull-left' width='20%' />";
                }

                ((Literal)e.Row.Cells[3].FindControl("litCorDeck")).Text = imagens;

                if (ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() != "0")
                {
                    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]) ||
                        DateTime.Now.Day <= Convert.ToInt32(ConfigurationManager.AppSettings["DIAFECHAMENTO"]))
                    {
                        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Enabled = true;

                    }
                    else
                    {
                        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Attributes.Add("onclick", "sweetAlert('Aviso!', 'Só é permitido realizar alterações no deck entre os dias " + ConfigurationManager.AppSettings["DIAABERTURA"].ToString() + " e " + ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() + ".', 'warning'); ");
                    }
                }
                else
                {
                    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]))
                    {
                        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Enabled = true;
                    }
                    else
                    {
                        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Attributes.Add("onclick", "sweetAlert('Aviso!', 'Só é permitido realizar alterações no deck a partir do dia " + ConfigurationManager.AppSettings["DIAABERTURA"].ToString() + " de cada mês.', 'warning'); ");
                    }
                }

                string button = "<button type='button' class='btn btn-default btn-xs' onclick=\"" +
                "$('#ContentPlaceHolder1_txtCartas').val('"+ listaCartas +"');" +
                "$('#deck').modal('show');" +
                "\">Ver cartas</button>";

                ((Literal)e.Row.Cells[4].FindControl("litDeck")).Text = button;
            }
        }

        protected void btnCadastrarDeck_OnClick(object sender, EventArgs e)
        {
            this.Response.Redirect("NovoDeck.aspx");
        }
    }
}