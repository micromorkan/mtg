﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dados;
using DAL;
using System.Data;
using System.Configuration;
using System.Runtime.Caching;

namespace BO
{
    public class Negocio
    {
        public void CadastarUsuario(Usuario user)
        {
            if (new Banco().VerificarUsuarioExistente(user.Email) > 0)
            {
                throw new LigaException { Texto = "Este email já está sendo usado.", TipoErro = TipoErro.Aviso };
            }

            new Banco().CadastrarUsuario(user);
        }

        public List<BanList> ObterBanList()
        {
            DataTable dt = new Banco().ObterBanList();
            List<BanList> lista = new List<BanList>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                BanList card = new BanList();

                card.Id = dt.Rows[i]["id"].ToString();
                card.Nome = dt.Rows[i]["nome"].ToString();
                card.Cor = dt.Rows[i]["cor"].ToString();
                card.ImagemUrl = dt.Rows[i]["imagemurl"].ToString();
                card.DataBanimento = dt.Rows[i]["databanimento"].ToString();

                lista.Add(card);
            }

            return lista;
        }

        public Usuario ValidarUsuario(Usuario user)
        {
            Usuario login = new Usuario();

            DataTable dt = new Banco().ValidarUsuario(user);

            if (dt.Rows.Count > 0)
            {
                login.Id = dt.Rows[0]["idusuario"].ToString();
                login.Nome = dt.Rows[0]["nome"].ToString();
                login.Email = dt.Rows[0]["email"].ToString();
            }
            else
            {
                throw new LigaException { Texto = "Email e/ou senha inválido(s)!", TipoErro = Dados.TipoErro.Aviso };
            }

            return login;
        }

        public bool ValidarEmailEmUso(Usuario user)
        {
            bool emailEmUso = false;

            DataTable dt = new Banco().ValidarEmailEmUso(user);

            if (dt.Rows.Count > 0)
            {
                emailEmUso = true;
            }

            return emailEmUso;
        }

        public void CadastrarDeck(Deck deck)
        {
            new Banco().CadastrarDeck(deck);
        }

        public List<Deck> ObterListaDecks(string idUsuario)
        {
            List<Deck> lista = new List<Deck>();

            DataTable dt = new Banco().ObterListaDecks(idUsuario);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Deck deck = new Deck();

                deck.Id = dt.Rows[i]["iddeck"].ToString();
                deck.Id_Usuario = dt.Rows[i]["idusuario"].ToString();
                deck.Tribo = dt.Rows[i]["tribo"].ToString();
                deck.Qtd_Cards = dt.Rows[i]["qtdcards"].ToString();
                deck.Lista_Cards = dt.Rows[i]["listacards"].ToString();
                deck.Data_Atualizacao = Convert.ToDateTime(dt.Rows[0]["dataatualizacao"]).ToString("dd/MM/yyyy HH:mm:ss");
                deck.Status = dt.Rows[i]["status"].ToString();
                deck.Cor_Deck = dt.Rows[i]["cordeck"].ToString();
                deck.Ativo = dt.Rows[i]["ativo"].ToString() == "0" ? "Não" : "Sim";

                lista.Add(deck);
            }

            return lista;
        }

        public Deck ObterDeckUsuario(Deck filtro)
        {
            Deck deck = new Deck();

            DataTable dt = new Banco().ObterDeckUsuario(filtro);

            if (dt.Rows.Count > 0)
            {
                deck.Id = dt.Rows[0]["iddeck"].ToString();
                deck.Id_Usuario = dt.Rows[0]["idusuario"].ToString();
                deck.Tribo = dt.Rows[0]["tribo"].ToString();
                deck.Qtd_Cards = dt.Rows[0]["qtdcards"].ToString();
                deck.Lista_Cards = dt.Rows[0]["listacards"].ToString();
                deck.Data_Atualizacao = dt.Rows[0]["dataatualizacao"].ToString();
                deck.Status = dt.Rows[0]["status"].ToString();
                deck.Cor_Deck = dt.Rows[0]["cordeck"].ToString();
                deck.Ativo = dt.Rows[0]["ativo"].ToString();
            }
            else
            {
                throw new LigaException { Texto = "Ocorreu um erro ao obter os dados!", TipoErro = Dados.TipoErro.Error };
            }

            return deck;
        }

        public void CadastrarBanList(BanList card)
        {
            new Banco().CadastrarBanList(card);
        }

        public void AtualizarDeck(Deck deck)
        {
            new Banco().GerarHistoricoEAtualizarDeck(deck);
        }

        public void DeletarDeck(Deck deck)
        {
            new Banco().DeletarDeck(deck);
        }

        public List<JogosView> ObterListaJogos(string idUsuario, string mesReferencia, string anoReferencia)
        {
            List<JogosView> lista = new List<JogosView>();

            DataTable dt = new Banco().ObterListaJogos(idUsuario, mesReferencia, anoReferencia);

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                JogosView jogo = new JogosView();

                if (dt.Rows[i]["empate"].ToString() == "1")
                {
                    jogo.Placar = "1 x 1";
                    jogo.Resultado = "<i class='glyphicon glyphicon-pause' style='color: #FFA500;'></i>";
                }
                else if (dt.Rows[i]["vencedor"].ToString() == idUsuario)
                {
                    jogo.Placar = dt.Rows[i]["placarv"].ToString() + " x " + dt.Rows[i]["placarp"].ToString();
                    jogo.Resultado = "<i class='glyphicon glyphicon-ok' style='color: #00FF00;'></i>";
                }
                else
                {
                    jogo.Placar = dt.Rows[i]["placarp"].ToString() + " x " + dt.Rows[i]["placarv"].ToString();
                    jogo.Resultado = "<i class='glyphicon glyphicon-remove' style='color: #FF0000;'></i>";
                }

                if (dt.Rows[i]["idusuariocad"].ToString() == idUsuario)
                {
                    if (dt.Rows[i]["status"].ToString() == "0")
                    {
                        jogo.Status = "Aguardando confirmação";
                    }
                    else
                    {
                        jogo.Status = "Duelo confirmado";
                    }
                }
                else
                {
                    if (dt.Rows[i]["status"].ToString() == "0")
                    {
                        string idJogo = "&quot;{&apos;idJogo&apos;: &apos;" + dt.Rows[i]["idjogos"].ToString() + "&apos;}\"";
                        jogo.Status = "<button class='btn btn-primary btn-xs' onclick='swal({ title: \"Você tem certeza?\", text: \"Após a confirmação não é possível reverter o resultado!\", type: \"warning\", showCancelButton: true, confirmButtonColor: \"#DD6B55\", confirmButtonText: \"Sim, Confirmar esse jogo!\", closeOnConfirm: false }, function(){ $.ajax({type: \"POST\",url: \"Jogos.aspx/ConfirmarJogo\",data: " + idJogo + ",contentType: \"application/json; charset=utf-8\",dataType: \"json\",success: function(response) { swal({ title: \"Sucesso!\", text: response.d, type: \"success\" }, function(){ window.location.href = \"Jogos.aspx\"; }); },error: function(response) { swal(\"Error!\", response.d, \"error\");}});});'>Confirmar</button>" +
                                      "&nbsp;<button class='btn btn-danger btn-xs' onclick='swal({ title: \"Você tem certeza?\", text: \"Após o cancelamento não é possível reverter o resultado!\", type: \"warning\", showCancelButton: true, confirmButtonColor: \"#DD6B55\", confirmButtonText: \"Sim, Deletar esse jogo!\", closeOnConfirm: false }, function(){ $.ajax({type: \"POST\",url: \"Jogos.aspx/CancelarJogo\",data: " + idJogo + ",contentType: \"application/json; charset=utf-8\",dataType: \"json\",success: function(response) { swal({ title: \"Sucesso!\", text: response.d, type: \"success\" }, function(){ window.location.href = \"Jogos.aspx\"; }); },error: function(response) { swal(\"Error!\", response.d, \"error\");}});});'>Cancelar</button>";
                    }
                    else
                    {
                        jogo.Status = "Duelo confirmado";
                    }
                }

                jogo.Data = Convert.ToDateTime(dt.Rows[i]["data"].ToString()).ToString("dd/MM/yyyy");
                jogo.Vencedor = dt.Rows[i]["vencedor"].ToString();
                jogo.TriboOponente = dt.Rows[i]["tribo_oponente"].ToString();
                jogo.Oponente = new Banco().PesquisarNomeUsuario(dt.Rows[i]["oponente"].ToString());
                jogo.DeckOponente = dt.Rows[i]["deck_oponente"].ToString();

                lista.Add(jogo);
            }

            return lista;
        }

        public void DeckPrincipal(Deck deck)
        {
            new Banco().DesativarTodosDecks(deck);
        }

        public List<Usuario> ObterJogadoresAtivos()
        {
            List<Usuario> lista = new List<Usuario>();

            DataTable dt = new Banco().ObterJogadoresAtivos();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                Usuario user = new Usuario();

                user.Nome = dt.Rows[i]["nome"].ToString() + " - " + dt.Rows[i]["tribo"].ToString();
                user.Id = dt.Rows[i]["idusuario"].ToString() + "&" + dt.Rows[i]["iddeck"].ToString();

                lista.Add(user);
            }

            return lista;
        }

        public void IncluirJogo(Jogos jogo)
        {
            List<Usuario> lista = new List<Usuario>();

            DataTable dt = new Banco().ObterJogosMensais(jogo.Id_Usuario_Cad, Convert.ToDateTime(jogo.Data).Month.ToString(), Convert.ToDateTime(jogo.Data).Year.ToString());

            if (dt.Rows.Count >= Convert.ToInt32(ConfigurationManager.AppSettings["NUMDUELOSMES"]))
            {
                throw new LigaException { Texto = "Você já realizou os " + ConfigurationManager.AppSettings["NUMDUELOSMES"] + " duelos do mês.", TipoErro = TipoErro.Aviso };
            }

            string idOponente = jogo.Id_Usuario_Cad == jogo.Id_Usuario_V ? jogo.Id_Usuario_P : jogo.Id_Usuario_V;

            DataTable dtt = new Banco().ObterJogosMensais(idOponente, Convert.ToDateTime(jogo.Data).Month.ToString(), Convert.ToDateTime(jogo.Data).Year.ToString());

            if (dtt.Rows.Count >= Convert.ToInt32(ConfigurationManager.AppSettings["NUMDUELOSMES"]))
            {
                throw new LigaException { Texto = "Seu oponente já realizou os " + ConfigurationManager.AppSettings["NUMDUELOSMES"] + " duelos do mês.", TipoErro = TipoErro.Aviso };
            }
            else
            {
                int countjogo = 0;

                for (int i = 0; i < dtt.Rows.Count; i++)
                {
                    if ((dtt.Rows[i]["idusuariov"].ToString() == jogo.Id_Usuario_Cad && dtt.Rows[i]["idusuariop"].ToString() == idOponente) ||
                        (dtt.Rows[i]["idusuariov"].ToString() == idOponente && dtt.Rows[i]["idusuariop"].ToString() == jogo.Id_Usuario_Cad))
                    {
                        countjogo++;

                        if (countjogo == Convert.ToInt32(ConfigurationManager.AppSettings["NUMDUELOSMESMOOPONENTE"]))
                        {
                            throw new LigaException { Texto = "Você já realizou " + ConfigurationManager.AppSettings["NUMDUELOSMESMOOPONENTE"] + " duelos com esse mesmo oponente neste mês.", TipoErro = TipoErro.Aviso };
                        }
                    }
                }
            }

            List<string> jogosGanhos = new List<string>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["idusuariov"].ToString() == jogo.Id_Usuario_Cad)
                {
                    jogosGanhos.Add(dt.Rows[i]["idusuariop"].ToString());
                }
            }

            if (string.IsNullOrEmpty(jogosGanhos.Find(x => x == idOponente)))
            {
                jogo.Ponto_Reduzido = "0";
            }
            else
            {
                jogo.Ponto_Reduzido = "1";
            }

            DateTime data = Convert.ToDateTime(jogo.Data);

            jogo.Data = data.Date.Year.ToString() + "-" + data.Date.Month.ToString().PadLeft(2, '0') + "-" + data.Date.Day.ToString().PadLeft(2, '0');

            new Banco().IncluirJogo(jogo);
        }

        public void ConfirmarJogo(string idJogo)
        {
            new Banco().ConfirmarJogo(idJogo);
        }

        public void CancelarJogo(string idJogo)
        {
            new Banco().CancelarJogo(idJogo);
        }

        public List<RankingView> ObterRankingMensal(string numMes, string numAno)
        {
            List<RankingView> listaOrdenada = new List<RankingView>();

            if (MemoryCache.Default["RANKING"] == null)
            {
                DataTable listaParticipantes = new Banco().ObterListaParticipantes(numMes, numAno);
                List<RankingView> listaRanking = new List<RankingView>();

                for (int i = 0; i < listaParticipantes.Rows.Count; i++)
                {
                    DataTable listaJogos = new Banco().ObterJogosMensais(listaParticipantes.Rows[i]["idusuario"].ToString(), numMes, numAno, true);
                    RankingView ranking = new RankingView();

                    int pontuacao = 0;
                    int numVitorias = 0;
                    int numEmpates = 0;
                    int numDerrotas = 0;
                    int numJogos = listaJogos.Rows.Count;

                    for (int x = 0; x < listaJogos.Rows.Count; x++)
                    {
                        if (listaJogos.Rows[x]["idusuariov"].ToString() == listaParticipantes.Rows[i]["idusuario"].ToString() && listaJogos.Rows[x]["pontoreduzido"].ToString() == "0" && listaJogos.Rows[x]["empate"].ToString() == "0")
                        {
                            pontuacao = pontuacao + 3;
                            numVitorias = numVitorias + 1;
                        }
                        else if (listaJogos.Rows[x]["idusuariov"].ToString() == listaParticipantes.Rows[i]["idusuario"].ToString() && listaJogos.Rows[x]["pontoreduzido"].ToString() == "1" && listaJogos.Rows[x]["empate"].ToString() == "0")
                        {
                            pontuacao = pontuacao + 2;
                            numVitorias = numVitorias + 1;
                        }
                        else if (listaJogos.Rows[x]["idusuariop"].ToString() == listaParticipantes.Rows[i]["idusuario"].ToString() && listaJogos.Rows[x]["pontoreduzido"].ToString() == "0" && listaJogos.Rows[x]["empate"].ToString() == "0")
                        {
                            pontuacao = pontuacao + 1;
                            numDerrotas = numDerrotas + 1;
                        }
                        else if (listaJogos.Rows[x]["empate"].ToString() == "1")
                        {
                            pontuacao = pontuacao + 1;
                            numEmpates = numEmpates + 1;
                        }
                    }

                    ranking.Pontuacao = pontuacao;
                    ranking.NumVitorias = numVitorias;
                    ranking.NumEmpates = numEmpates;
                    ranking.NumDerrotas = numDerrotas;
                    ranking.NumJogos = numJogos;
                    ranking.Nome = listaParticipantes.Rows[i]["nome"].ToString();
                    ranking.Tribo = listaParticipantes.Rows[i]["tribo"].ToString();
                    ranking.Deck = listaParticipantes.Rows[i]["listacards"].ToString();

                    listaRanking.Add(ranking);
                }

                listaOrdenada = listaRanking.OrderByDescending(x => x.Pontuacao).ThenByDescending(x => x.NumVitorias).ThenByDescending(x => x.NumEmpates).ThenBy(x => x.Nome).ToList();

                int posicao = 1;

                foreach (RankingView item in listaOrdenada)
                {
                    item.Posicao = posicao.ToString() + "º";
                    posicao++;
                }

                MemoryCache.Default.Add("RANKING", listaOrdenada, new DateTimeOffset(DateTime.Now.AddMinutes(1)));
            }
            else
            {
                listaOrdenada = listaOrdenada = (List<RankingView>)MemoryCache.Default.Get("RANKING"); 
            }

            return listaOrdenada;
        }
    }
}
