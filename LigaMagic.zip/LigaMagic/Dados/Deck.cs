﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dados
{
    public class Deck
    {
        public string Id { get; set; }
        public string Id_Usuario { get; set; }
        public string Tribo { get; set; }
        public string Qtd_Cards { get; set; }
        public string Lista_Cards { get; set; }
        public string Data_Atualizacao { get; set; }
        public string Cor_Deck { get; set; }
        public string Status { get; set; }
        public string Ativo { get; set; }
    }
}
