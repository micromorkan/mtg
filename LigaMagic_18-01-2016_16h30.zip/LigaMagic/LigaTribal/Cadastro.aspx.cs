﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using Dados;

namespace LigaTribal
{
    public partial class Cadastro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCadastrar_OnClick(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNome.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorNome", "<script> sweetAlert('Aviso!', 'Campo Nome não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtEmail.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmail", "<script> sweetAlert('Aviso!', 'Campo Email não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtSenha.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorSenha", "<script> sweetAlert('Aviso!', 'Campo Senha não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtRepeteSenha.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorRepeteSenha", "<script> sweetAlert('Aviso!', 'Campo Repete Senha não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (txtSenha.Text.Length < 6)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorSenhaCurta", "<script> sweetAlert('Aviso!', 'Campo Senha muito curto. A senha deve conter mais de 6 dígitos.', 'warning'); </script> ", false);
            }
            else if (txtSenha.Text != txtRepeteSenha.Text)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorSenhaDiferente", "<script> sweetAlert('Aviso!', 'Campo Senha e Repete Senha estão diferentes.', 'warning'); </script> ", false);
            }
            else if (!txtEmail.Text.Contains('@') || !txtEmail.Text.Contains('.'))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmailInvalido", "<script> sweetAlert('Aviso!', 'Campo Email está incorreto.', 'warning'); </script> ", false);
            }
            else if (!chkRegras.Checked)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmailInvalido", "<script> sweetAlert('Aviso!', 'Você não aceitou os termos e regras do TribalWars.', 'warning'); </script> ", false);
            }
            else if (new Negocio().ValidarEmailEmUso(new Usuario { Email = txtEmail.Text.Trim() }))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmailEmUso", "<script> sweetAlert('Aviso!', 'Este email já está sendo utilizado.', 'warning'); </script> ", false);
            }
            else
            {
                Usuario user = new Usuario();

                user.Nome = txtNome.Text;
                user.Email = txtEmail.Text;
                user.Senha = txtSenha.Text;

                try
                {
                    new Negocio().CadastarUsuario(user);
                    ((Button)sender).Enabled = false;

                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SucessoCadastro", "<script> swal({ title: 'Sucesso!', text: 'Cadastro realizado.', type: 'success' }, function(){ window.location.href = 'Index.aspx'; }); </script> ", false);
                }
                catch (LigaException lex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Aviso!', '" + lex.Texto + "', '" + lex.TipoErro.ToDescriptionString() + "'); </script> ", false);
                }
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorEmailInvalido", "<script> sweetAlert('Erro!', 'Não foi possível cadastrar. [" + ex.Message.Replace("'", "%") + "]', 'error'); </script> ", false);
                }
            }
        }
    }
}