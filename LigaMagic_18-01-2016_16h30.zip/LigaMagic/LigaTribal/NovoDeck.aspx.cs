﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Dados;
using BO;
using System.Configuration;

namespace LigaTribal
{
    public partial class NovoDeck : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["USER"] == null)
                {
                    Response.Redirect("Index.aspx");
                }
                else
                {
                    hdfIdUsuario.Value = ((Usuario)Session["USER"]).Id;
                    ConfigurarTela();
                }
            }

            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "MENU", "<script>$('li').removeClass('active'); $('ul li:nth-child(3)').addClass('active'); </script>", false);
        }

        private void ConfigurarTela()
        {
            if (ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() != "0")
            {
                if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]) ||
                    DateTime.Now.Day <= Convert.ToInt32(ConfigurationManager.AppSettings["DIAFECHAMENTO"]))
                {
                    rdlPrincipal.Enabled = true;
                }
                else
                {
                    rdlPrincipal.Enabled = false;
                }
            }
            else
            {
                if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]))
                {
                    rdlPrincipal.Enabled = true;
                }
                else
                {
                    rdlPrincipal.Enabled = false;
                }
            }
        }

        protected void btnVoltar_OnClick(object sender, EventArgs e)
        {
            this.Response.Redirect("Decks.aspx");
        }

        protected void btnSalvar_OnClick(object sender, EventArgs e)
        {
            int numCartas = 0;

            if (ddlTribo.SelectedItem.Value == "0")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorTribo", "<script> sweetAlert('Aviso!', 'Escolha uma tribo.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtQtdCartas.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtd", "<script> sweetAlert('Aviso!', 'Campo Qtd Cartas não foi preenchido.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(cklCor.SelectedItem.Value))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorCor", "<script> sweetAlert('Aviso!', 'Selecione pelo menos uma cor do seu deck.', 'warning'); </script> ", false);
            }
            else if (string.IsNullOrEmpty(txtCartas.Text))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorCartas", "<script> sweetAlert('Aviso!', 'Preencha sua lista de cartas.', 'warning'); </script> ", false);
            }
            else if (!Int32.TryParse(txtQtdCartas.Text, out numCartas))
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtdValor", "<script> sweetAlert('Aviso!', 'Campo Qtd Cartas deve ser numérico.', 'warning'); </script> ", false);
            }
            else if (numCartas < 60)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "ErrorQtdMin", "<script> sweetAlert('Aviso!', 'O número de cartas não pode ser inferior a 60.', 'warning'); </script> ", false);
            }
            else
            {
                Deck deck = new Deck();

                deck.Id_Usuario = hdfIdUsuario.Value;
                deck.Qtd_Cards = numCartas.ToString();
                deck.Tribo = ddlTribo.SelectedItem.Value;
                deck.Lista_Cards = txtCartas.Text;

                if (ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() != "0")
                {
                    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]) ||
                        DateTime.Now.Day <= Convert.ToInt32(ConfigurationManager.AppSettings["DIAFECHAMENTO"]))
                    {
                        deck.Ativo = rdlPrincipal.SelectedItem.Value;
                    }
                    else
                    {
                        deck.Ativo = "0";
                    }
                }
                else
                {
                    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]))
                    {
                        deck.Ativo = rdlPrincipal.SelectedItem.Value;
                    }
                    else
                    {
                        deck.Ativo = "0";
                    }
                }

                foreach (ListItem item in cklCor.Items)
                {
                    if (item.Selected)
                    {
                        deck.Cor_Deck = deck.Cor_Deck + item.Value;
                    }
                }

                try
                {
                    if (deck.Ativo == "1")
                    {
                        new Negocio().DeckPrincipal(deck);
                    }

                    new Negocio().CadastrarDeck(deck);
                    ((LinkButton)sender).Enabled = false;

                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SucessoNovoDeck", "<script> swal({ title: 'Sucesso!', text: 'Deck registrado.', type: 'success' }, function(){ window.location.href = 'Decks.aspx'; }); </script> ", false);
                }               
                catch (Exception ex)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), "SweetAlert", "<script> sweetAlert('Erro!', '" + ex.Message.Replace("'", "%") + "', 'error'); </script> ", false);
                }
            }
        }
    }
}