﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LigaTribal
{
    public partial class BanList : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void grvBanlist_OnDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                //string cor = ((Deck)e.Row.DataItem).Cor_Deck;
                //string listaCartas = ((Deck)e.Row.DataItem).Lista_Cards;
                //string imagens = string.Empty;

                //for (int i = 0; i < cor.Length; i++)
                //{
                //    imagens = imagens + "<img src='images/" + cor.Substring(i, 1) + ".png' class='img-responsive pull-left' width='20%' />";
                //}

                //((Literal)e.Row.Cells[3].FindControl("litCorDeck")).Text = imagens;

                //if (ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() != "0")
                //{
                //    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]) ||
                //        DateTime.Now.Day <= Convert.ToInt32(ConfigurationManager.AppSettings["DIAFECHAMENTO"]))
                //    {
                //        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Enabled = true;

                //    }
                //    else
                //    {
                //        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Attributes.Add("onclick", "sweetAlert('Aviso!', 'Só é permitido realizar alterações no deck entre os dias " + ConfigurationManager.AppSettings["DIAABERTURA"].ToString() + " e " + ConfigurationManager.AppSettings["DIAFECHAMENTO"].ToString() + ".', 'warning'); ");
                //    }
                //}
                //else
                //{
                //    if (DateTime.Now.Day >= Convert.ToInt32(ConfigurationManager.AppSettings["DIAABERTURA"]))
                //    {
                //        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Enabled = true;
                //    }
                //    else
                //    {
                //        ((LinkButton)e.Row.Cells[3].FindControl("btnEditar")).Attributes.Add("onclick", "sweetAlert('Aviso!', 'Só é permitido realizar alterações no deck a partir do dia " + ConfigurationManager.AppSettings["DIAABERTURA"].ToString() + " de cada mês.', 'warning'); ");
                //    }
                //}

                //string button = "<button type='button' class='btn btn-default btn-xs' onclick=\"" +
                //"$('#ContentPlaceHolder1_txtCartas').val('" + listaCartas + "');" +
                //"$('#deck').modal('show');" +
                //"\">Ver cartas</button>";

                //((Literal)e.Row.Cells[4].FindControl("litDeck")).Text = button;
            }
        }
    }
}